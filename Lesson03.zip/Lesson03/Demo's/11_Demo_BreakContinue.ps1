#
# Let's Demo a Break Statement. When the counter equals 5 break out of the loop
# Event Though the Loop should exit at 10.

$Counter = 0
Do {
    Write-Host $Counter
    Start-Sleep -Seconds 1
    # Let's 
    if ($Counter -eq 5) {
        # We are going to break the loop
        Break
    }
    $Counter++
} Until ($Counter -eq 10)

# Print the Counter Value to show 5
Write-Host "This is the output $Counter"


#
# Let's demo the continue statment

$Counter = 0

Do {

    Write-Host "I am some code"
    $Counter++
    # We are going to run continue statment skipping this current iteration of the loop
    Continue
    # Now the code below will be skipped since the continue statment will 
    Write-Host "This code won't be run!"

} Until ($Counter -eq 10)
