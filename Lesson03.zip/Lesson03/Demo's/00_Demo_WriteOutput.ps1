# Declare an Array
$Array = @(1,2,3,4,5,6,7)

Write-Output $Array

#
$Array | ForEach-Object {

    Write-Output $_

} | ForEach-Object { Write-Host "Write_host: $($_)"}

#
# This is treated as a write output as well.

$Array | ForEach-Object {

   $_

} | ForEach-Object { Write-Host "Write_host: $($_)"}


#
# This won't

$Array | ForEach-Object {

    $null = $_
 
 } | ForEach-Object { Write-Host "Write_host: $($_)"}