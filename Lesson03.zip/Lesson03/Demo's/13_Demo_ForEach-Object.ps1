#
# Let's take a look at ForEach-Object

$Processes = Get-Process

$Processes | ForEach-Object {
    # To Reference the Current Item in the Array/Collection we use $_
    Write-Host $_.Name
}

