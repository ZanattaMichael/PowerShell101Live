#
# A Simple Example of ForEach

# Fetch all the Processes
$Processes = Get-Process

# Using ForEach we can iterate through each of the items
ForEach ($Process in $Processes) {
    # Note that we are using the Object $Process to get the item.
    Write-Host "Process Name: $($Process.Name) Process ID: $($Process.Id) MEOW!"
}

# Also Note that the object $Process Exists after the loop
# Let's fetch the object
$Process

#
