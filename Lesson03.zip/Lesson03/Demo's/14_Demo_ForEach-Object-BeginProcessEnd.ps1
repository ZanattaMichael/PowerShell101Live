#
# Let's take a look at the Begin Process and End Blocks

$Processes = Get-Process

$Processes | ForEach-Object -Begin {
    # Declare an collection
    $collection = @()
} -Process {
    # Iterate through each item within the array/collection
    $collection += [PSCustomObject]@{
        RandomPropertyName = $_.Name
        RandomIdName= $_.Id
    }
} -End {
    # Return the Custom Collection to the Pipeline
    Write-Output $collection
}

