#
# The Semicolon denotes the end of a statement.
# You can combine multiple lines together

$Processes = Get-Process
Write-host $Processes[0].Name

# Let's combine the two statements on the same line with a ";"
$Processes = Get-Process; Write-Host $Processes[0].Name
