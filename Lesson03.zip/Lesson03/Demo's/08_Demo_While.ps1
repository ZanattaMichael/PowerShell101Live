#
# The while loop is the opposite to the do loop. The condition will be evaluated first

# Declare a Varaible
$var = $true

# Enter the loop only if $var is $false
While (-not($var)) {
    # This won't enter
    Write-Host "I won't be executed"
}

Write-Host "End of Script"
