#
# This is a test using a sleep and the counter so we can compare the differences 
# of do {} while() and do {} until()

#
# Test 1

$counter = 0

Do {
    Start-Sleep -Seconds 1
    # Add to the counter
    $counter++
} While ($counter -ne 10)
# In this example the loop will continue if the condition is NOT met. Pessimistic.

#
# Test 2

$counter = 0

Do {
    Start-Sleep -Seconds 1
    # Add to the counter
    $counter++
} Until ($counter -eq 10 ) 
# In this example the loop will continue until the condition IS met. Optermistic