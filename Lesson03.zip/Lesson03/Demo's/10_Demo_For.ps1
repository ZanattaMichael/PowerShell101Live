# Let's Count to 10
#
# We Declared $i to be 0
# Condition $i -not equal to 10
# Add 1 to $i

For ($i =0; $i –ne 10; $i++) {
	Write-Host $i
}

# Let's break down the Initialization, Condition Repeat it easier visulize it this way

For (
	$i = 0 # Initalization
	$i -ne 10 # Condition
	$i++ # Repeat
) {
	Write-Host $i
}

#
# Let's count back from 10, by using $i--

For ($i = 10; $i -ne 0; $i--) {
	Write-Host $i
}

#
# Let's count in two's

For ($i = 0; $i -ne 20; $i=$i+2) {
	Write-Host $i
}

For ($i = 0; $i -ne 20; $i++,$i++) {
	Write-Host $i
}

#
# Now let's load the processes

$Processes = Get-Process

For ($i = 0; $i -ne $Processes.Count; $i++) {
	# Now let's print the name property, by indexing through the array
	# We call the collection, pass the $i integer as an index into the collection and call the property name	
	$Processes[$i].Name
}
