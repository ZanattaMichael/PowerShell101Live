#
# ForEach Object Shanaggians
# In this demo we will be looking at the break, return & continue

# Let's demonstrate a break after a count of 5

$Counter = 0
$Processes = Get-Process

# Iterate Through Each of the Processes
$Processes | ForEach-Object {
    Write-Host "Counter $Counter"
    $counter++
    # When the Counter Equals 5 break the loop
    if ($Counter -ge 5) {
        Write-Host "Hit the Count of 5. Breaking the Loop"
        break
    }
}

# Breaking the loop is standard. Let's now use return to iterate to the next item within the loop

$Counter = 0
$Processes = Get-Process | Select-Object -First 10

# Iterate Through Each of the Processes
$Processes | ForEach-Object {
    Write-Host "Counter $Counter"
    $counter++
    # When the Counter is equal of greater then 5 move to the next item in the loop
    if ($Counter -ge 5) {
        Write-Host "Hit the Count of 5. Returning the Loop"
        return
    }
    # Some Extra Code
    # When the counter is greater then 5, the return will trigger moving onto the next item
    # This code won't be executed.
    Write-Host "I'm some extra code!"
}

#
# Now let's get super wierd here with the continue statement.

$Counter = 0
$Processes = Get-Process

# Iterate Through Each of the Processes
$Processes | ForEach-Object {
    Write-Host "Counter $Counter"
    $counter++
    # When the Counter Equals 5 break the loop
    if ($Counter -ge 5) {
        Write-Host "Hit the Count of 5. We are going to 'continue' the Loop"
        continue
    }
}

# Looks normal right. Well that's because we haven't nested foreach-objects
# Now lets look at this weirdness

$Counter = 0
$Processes = @(1,2,3,4,5,6)

# Iterate Through Each of the Processes
$Processes | ForEach-Object {
    # Print to the Screen
    Write-Host "Inside the first loop. Haven't entered the second loop."
    # Declare another array and pipe it into ForEach-Object
    @(1,2,3,4,5,6) | ForEach-Object {

        Write-Host "Inside the loop. Before the continue statment."
        # We need to write somthing back into the pipeline or it will be empty
        # Let's do that
        Write-Output "Back in the pipeline"
        # Now are you ready for the shanaggians?
        # When we use continue, this will return to the powershell pipeline
        continue

    }
    # No code should be executed here
    Write-Host "I never got executed"
}

# So what happened here? When the continue statement is called, it will return back
# to the powershell pipeline. Irreguardless of the output. Weird huh?#
# As a rule of thumb, you won't need to use it. But since it's used as a method to iterate
# to the next item in the collection, it's good to be aware of it.

