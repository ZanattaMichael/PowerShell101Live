#
# Let's demo loop labels.
#
# In this example we will demonstate how a child loop can exit a parent loop
# We will see:
# 1: The script enter the parent loop
# 2: The script enter the child loop.
# 3: The loop will process 5 times. We will see it count to 5.
# 4: Once reaching 5 the process will exit the parent loop.

# Declare a label
$ParentCounter = 0

# Declare the Loop
:ParentLabel Do {
        # This is the Parent Loop
        Write-Host "I am in the paraent loop."
        # Lets index into a child loop
        $ChildCounter = 0
        :ChildLabel Do {
            # Print the Child Loop Counter
            Write-Host "In Child Counter: $ChildCounter"
            # Now when the label is equal to 5 exit the parent loop
            if ($ChildCounter -eq 5) {
                break ParentLabel
            }
            # Add to the Child Counter
            $ChildCounter++
        } Until ($ChildCounter -eq 10)
    # Add to the Counter 
    $ParentCounter++
} Until ($ParentCounter -eq 10)

Write-Host "Yep Out of the loop!"