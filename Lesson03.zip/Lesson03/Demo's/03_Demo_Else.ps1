#
# Else is used when all other conditions are not met

# Declare an Array
$array = @(1,2,3,4,5)

if (6 -in $array) {
    # This won't get executed
    Write-Host "This won't get executed"
} Else {
    Write-Host "This will get executed."
}

#
# Lets use the previous ELseIf Example.


$File1 = Get-Content -LiteralPath ".\mockdata.txt"
$File2 = Get-Content -LiteralPath ".\mockdata2.txt"

# Construct the condition using elseif

# Both Files have content
if (($File1 -eq $null) -and ($File2 -eq $null)) {
    Write-Host "First Block"
} 
# File 1 has content, however file2 dosen't
elseif (($File1 -ne $null) -and ($File2 -eq $null)) {
    Write-Host "Second Block"
}
# File 1 dosen't have content, however file2 does.
elseif (($File1 -eq $null) -and ($File2 -ne $null)) {
    Write-Host "Third Block"
}
# Both files have content
elseif (($File1 -ne $null) -and ($File2 -ne $null)) {
    Write-Host "Fourth Block"
} 
# When everything else fails.
else {
    Write-Host "Here"
}

#
# A Better way to do it
#

#
# Lets use the previous ELseIf Example.
# Rather then having a final if, we can be certian that they only other condition
# would be Both files have content


$File1 = Get-Content -LiteralPath ".\mockdata.txt"
$File2 = Get-Content -LiteralPath ".\mockdata2.txt"

# Construct the condition using elseif

# Both Files have content
if (($File1 -eq $null) -and ($File2 -eq $null)) {
    Write-Host "First Block"
} 
# File 1 has content, however file2 dosen't
elseif (($File1 -ne $null) -and ($File2 -eq $null)) {
    Write-Host "Second Block"
}
# File 1 dosen't have content, however file2 does.
elseif (($File1 -eq $null) -and ($File2 -ne $null)) {
    Write-Host "Third Block"
}
# Both files have content
else {
    Write-Host "Here"
}