#
# This is a simple example of a do loop

# Declare a Variable to be $true
$val = $true

Do {
    # Sleep
    Start-Sleep -Seconds 5
} Until ($val)

# In this example the code will execute first before evaluating the condition
