#
# Initial Switch Statement

$string = "Hello"

Switch ($string) {
    "Hello" {
        Write-Host "Hey I'm Here!"
    }
    "Some Other String" {
        Write-host "I won't execute here!"
    }
    "Another Random String" {
        Write-Host "Neither Here!"
    }
}

#
# Switch Statments will compare other values in the condition

$string = "Hello"

Switch ($string) {
    "Hello" {
        Write-Host "Hey I'm Here!"
    }
    "Some Other String" {
        Write-host "I won't execute here!"
    }
    "Another Random String" {
        Write-Host "Neither Here!"
    }
    "Hello" {
        Write-Host "What? I'm being executed again? Hi There!"
    }
}

# 
# To Stop this behaviour, include the break statment inside the scriptblock
# This will exit the switch condition 

$string = "Hello"

Switch ($string) {
    "Hello" {
        Write-Host "Hey I'm Here!"
        break
    }
    "Some Other String" {
        Write-host "I won't execute here!"
        break
    }
    "Another Random String" {
        Write-Host "Neither Here!"
        break
    }
    "Hello" {
        Write-Host "What? I'm being executed again? Hi There!"
        break
    }
}

#
# The Default Operator is used like an "else", when all other conditions are NOT met.


$string = "Never gonna give you up. Never gonna let you down."

Switch ($string) {
    "Hello" {
        Write-Host "Hey I'm Here!"
        break
    }
    "Some Other String" {
        Write-host "I won't execute here!"
        break
    }
    "Another Random String" {
        Write-Host "Neither Here!"
        break
    }
    "Hello" {
        Write-Host "What? I'm being executed again? Hi There!"
        break
    }
    Default {
        Write-Host "Really? A RickRoll?"
    }
}