#
# Initial Demo Showcasing ElseIf

$array = (1,2,3,4,5,6,7)

if (8 -in $array) {
    # 8 is in the array
} elseif (1 -in $array) {
    # The condition will revaluate to be true 
    Write-Host "Success!"
}

#
# A more practical use of elseif.
# Consider the following scenario
# You are reading content from two files and depending if the content exists, perform different actions.
# This presents a problem. The problem is that there are 4 scenarios that could occur
# 1: Both files have content
# 2: The First file has content, however the second is $null.
# 3: The First file is null, however the second has contnet.
# 4: Neither files have content
#
# In this situation we are going to use elseif and the -and statement to overcome this issue:
#

$File1 = Get-Content -LiteralPath ".\mockdata.txt" -ErrorAction SilentlyContinue
$File2 = Get-Content -LiteralPath ".\mockdata2.txt" -ErrorAction SilentlyContinue

# Construct the condition using elseif

# Both Files have content
if (($File1 -eq $null) -and ($File2 -eq $null)) {
    Write-Host "First Block"
} 
# File 1 has content, however file2 dosen't
elseif (($File1 -ne $null) -and ($File2 -eq $null)) {
    Write-Host "Second Block"
}
# File 1 dosen't have content, however file2 does.
elseif (($File1 -eq $null) -and ($File2 -ne $null)) {
    Write-Host "Third Block"
}
# Both files have content
elseif (($File1 -ne $null) -and ($File2 -ne $null)) {
    Write-Host "Fourth Block"
}

#
#
#