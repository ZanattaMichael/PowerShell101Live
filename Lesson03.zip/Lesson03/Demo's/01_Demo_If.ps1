# If Statement - Success
#

$array = @(1,2,3,4,5,6)

# Test if the Integer 1 exists in the array
if (1 -in $array) {
    Write-Host "Success!"
}

#
# If Statment - Using a Not statement to flip the bit on an array

$array = @(2,3,4,5,6,7)
if (-not(1 -in $array)) {
    Write-Host "Success!"
}

# An use case, using Test-Path
if (Test-Path -LiteralPath D:\) {
    Write-Host "Success!"
}

# The File Dosen't Exist. Throw an Error
if (-not(Test-Path -LiteralPath Y:\)) {
    Throw "File dosen't exist"
}
if ((Test-Path -LiteralPath Y:\) -eq $false) {
    Throw "File dosen't exist"
}

#
# Use If Statment to Find Element in Array - Failure

$array = @(2,3,4,5,6)

# Test if the Integer 1 exists in the array
if (1 -in $array) {
    Write-Host "Success!"
}
