# Contains
@(1,2,3,4,5) -contains 1
@(1,2,3,4,5) -contains 6
# Not Contains
@(1,2,3,4,5) -notcontains 1
@(1,2,3,4,5) -notcontains 6
# In
1 -in @(1,2,3,4,5)
6 -in @(1,2,3,4,5)
# NotIn
1 -notin @(1,2,3,4,5)
6 -notin @(1,2,3,4,5)

#
# Test-Path
if (Test-Path -LiteralPath C:\Windows) {
    # Nothing in here
} else {
    # Main code here.
}

if (-not(Test-Path -LiteralPath C:\Windows)) {

}

Do {

    if (Test-Path -LiteralPath C:\Windows) {
        # Main Code.
    } else {
        # Tiny bit of code here
        # Skip onto the next loop item
        continue
    }

} Until ($true)


Do {

    if (-not(Test-Path -LiteralPath C:\Windows)) {
        Continue
    }

    # Everything is Implicitly True
    

} Until ($true)
