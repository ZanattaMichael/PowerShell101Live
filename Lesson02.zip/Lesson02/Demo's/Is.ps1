#Is
"THIS IS A STRING" -is [String]
"THIS IS A STRING" -is [Int]

#IsNot
"THIS IS A STRING" -isnot [String]
1 -isnot [String]
