# Standard Out-GridView
Get-Process | Out-GridView
# Using -PassThrough
Get-Process | Out-GridView -PassThru | ForEach-Object {$_.Id}