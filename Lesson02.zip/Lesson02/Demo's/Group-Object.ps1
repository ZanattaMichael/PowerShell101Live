#
# Group Object

#
# Start Multiple Instances of MSPaint
mspaint.exe
mspaint.exe
mspaint.exe
# Group the Items
$groupedObjects = Get-Process | Group-Object -Property ProcessName
# Let's Use Where Object to get the same ones
$groupedObjects = $groupedObjects | Where-Object {$_.Count -gt 1}
