# Get processes -> Default Properties
Get-Process | Format-List
# Get process -> Show all properties
Get-Process | Format-List -Property *
Get-Process | fl *
# Get Process -> Group by Name
Get-Process | Format-List -GroupBy ProcessName
