# Default Format Table
Get-Process | Format-Table
# Format only on Name, CPU, Path . Let's wrap text to the next line
Get-Process | Format-Table -Property ProcessName, CPU, Path -Wrap
# Group the Items
Get-Process | Format-Table -Property ProcessName, CPU, Path -GroupBy ProcessName