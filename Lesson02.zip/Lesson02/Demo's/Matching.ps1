# Matching
"string" -match "[a-z]"
123 -match "[a-z]"

# Not Matching
123 -notmatch "[a-z]"
"string" -notmatch "[a-z]"