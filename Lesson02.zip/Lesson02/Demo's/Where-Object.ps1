# Get-Process

# Start MSPaint
mspaint.exe

# MsPaint has Started and we are going to find it.
Get-Process | Where-Object ProcessName -like "*paint*" 
# Let's refactor the code to say mspaint
Get-Process | Where-Object ProcessName -EQ "mspaint"

#
# Another way to write this
Get-Process | Where-Object { $_.ProcessName -eq "mspaint" }
# Let's write an Interesting Query
# Let's get a list of Processes that are over 10% and are a system process (in C:\Windows\System32 directory)

# We are going to use the Path Property
# We are going to use the CPU Property (The CPU Property can null.)

$results = Get-Process | Where-Object { (($_.CPU -ne $null) -and ($_.CPU -ge 10) -and ($_.Path -like "C:\Windows\System32\*")) }

