# Using Case Sensitive Matching
"THIS IS A STRING" -eq "this is a string"
"THIS IS A STRING" -ceq "this is a string"

# Using Case Insensitive Matching
"THIS IS A STRING" -eq "this is a string"
"THIS IS A STRING" -ieq "this is a string"

