# Equals
"String" -eq "String"
"string" -eq "string"
1 -eq "string"
# Not Equals
"string" -ne "this is a string"
"string" -ne 1
"string" -ne "string"
# Greater Than
2 -gt 1
1 -gt 2
# Less Than
1 -lt 2
2 -lt 1
# Greater or Equal to
2 -ge 2
2 -ge 1
1 -ge 2
# Less or Equal to
2 -le 2
1 -le 2
2 -le 1