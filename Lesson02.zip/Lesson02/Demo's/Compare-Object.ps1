#
# Compare Object

# Get-Process
mspaint.exe
mspaint.exe
mspaint.exe
# Group the Items
$groupedObjects = Get-Process | Group-Object -Property ProcessName
# Let's Use Where Object to get the same ones
$mspaintGroupedObjects = $groupedObjects | Where-Object {$_.Name -eq "mspaint"}

Compare-Object -ReferenceObject $mspaintGroupedObjects.Group[0] -DifferenceObject $mspaintGroupedObjects.Group[1] -Property Id


# Array
$arrayA = @(1,2,3,4,5,1,1,1,1,6)
$arrayB = @(6,5,4,3,2,1)

Compare-Object -ReferenceObject $arrayA -DifferenceObject $arrayB



