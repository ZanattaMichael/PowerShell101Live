# Replace
"Hello World" -replace "Hello", "Hi"
"Hello World" -replace "\b", "-"
