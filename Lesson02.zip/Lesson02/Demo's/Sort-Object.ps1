#
# Using Get-Process, sort on the CPU
Get-Process | Sort-Object -Property CPU
# Let's go one step further and get the Highest CPU intensive processes
Get-Process | Sort-Object -Property CPU -Descending
# Let just get a list of Process (No Duplicates)
Get-Process | Sort-Object -Property ProcessName -Unique
# Another way to illistrate this
@(1,2,3,4,5,1,1,1,1,1,1,1,1) | Sort-Object -Unique