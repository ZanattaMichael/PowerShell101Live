#
# Format List

# Quick and Easy was of viewing your data
Get-Process | Select -First 1 | Format-List *

