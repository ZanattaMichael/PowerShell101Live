#
# Convert To JSON

Get-Process | ConvertTo-Json | Out-File ".\ConvertToJson-Demo.json"

#
# Import the JSON Data

$var = Get-Content -Path ".\ConvertToJson-Demo.json"  | ConvertFrom-Json
# Show the type
$var | Get-Member