
#
# Troubleshoot the Following
#

$Files = Get-ChildItem -LiteralPath "D:\Temp"

# This If Statement Should be met. Somthing is wrong with it
# Test to see if it contains .exe files

if ($Files -in ".exe") {
    Write-Host "Yes Exe Files are Present"
}

# Correct Answer
if ($Files.Extension -contains ".exe") {
    Write-Host "Yes Exe Files are Present"
}

#
# Step Into
#$var = $(
#    Write-Host "ERE"
#     Get-ChildItem -LiteralPath "C:\Windows" -File -Recurse
#)

#$var | Where-Object {$_.Extension -eq ".exe"}

#
# Step Over

$temp = $var | Select-Object -First 10 | Where-Object {$_.Extension -eq ".exe"}

Write-Host "Something Else Here"

#
# Step Out Of Loop

$temp = $var | Select-Object -First 10 | Where-Object {$_.Extension -eq ".exe"}

Write-Host "Stepped Out"
