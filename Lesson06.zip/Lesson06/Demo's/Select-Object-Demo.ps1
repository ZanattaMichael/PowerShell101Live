#
# Default Use of Select Object

$var = Get-Process | Select-Object Name
# Use the Alias
$var = Get-Process | Select Name

# Gotcha's with Select-Object

$var -eq "test" # will fail
$var.name -eq "test" # will succeed

# Select Object Creates an Object with the Property

# Select -ExpandProperty to return a string array of data
$var = Get-Process | Select -ExpandProperty Name

#
# Other Things That Select-Object can do

# Using the -First Parameter
Get-Process | Select -ExpandProperty Name -First 5
# Using the -Last Parameter
Get-Process | Select -ExpandProperty Name -Last 5

# Quick and Dirty way to get the 5 item within the array
Get-Process | Select -ExpandProperty Name -First 5 | Select -Last 1

# Select * Similar to SQL
Get-Process | Select *

# Excluding Properties within Select.
# You need to have the property selected before you can exclude it
Get-Process | Select-Object -Property Name -ExcludeProperty Name

#
# Select Expressions

Get-Process | Select-Object @{Name="Test Property";Expression={Write-Output ("HELLO WORLD {0}" -f  $_.Name)}}


