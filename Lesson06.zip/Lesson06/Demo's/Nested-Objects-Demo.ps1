
#
# Get the Date of the Week

$Date = Get-Date

do { 
    if ($Date.DayOfWeek -eq "Monday") {
        $DayCount = 1
    }

} Until ($Counter -eq 7)

#
# Replace all that with this:
$Date.DayOfWeek.value__

# If $DayCount is week one, return file 1
if ($DayCount -le 5){
    Invoke-Item -LiteralPath "E:\Temp\1.txt"
}

# If $DayCount is week two, return file 2
elseif ($DayCount -ge 6){
    Invoke-Item -LiteralPath "E:\Temp\2.txt"
}

#
#