<#
Develop a basic script to create a Virtual Machine                    in Client-Hyper-V
Create a VM
Allocate Memory
Create a Disk
Attach the Disk
Start VM

#>

#
# We need to ask for a VM Name

$VMName = Read-Host -Prompt "Enter in the VM Name"
$VMPath = Read-Host -Prompt "Enter in the VM Path"
$VMDiskSize = Read-Host -Prompt "Enter in Disk Size"

#
# We need to test if the VM Already Exists, If the Path Already Exists and
# If the path is dodgy.

# Test the VM Name
if (Get-VM -Name $VMName) {
    Throw "VM Already Exists!"
}
# Test the VM Path
if (Test-Path -LiteralPath $VMPath) {
    Throw "Path Already Exists!"
} 
# Test to make sure the user didn't put a dodgy path in
if (-not(Test-Path -LiteralPath $VMPath -IsValid)) {
    Throw "Directory Path is not Valid!"
}

#
# Set the ErrorActionPreference to stop
$ErrorActionPreference = "Break"

#
# We need to Create our VM

$params = @{
    Name = $VMName
    Path = $VMPath
    NewVHDPath = Join-Path -Path $VMPath -ChildPath "$VMName.vhdx"
    NewVHDSizeBytes = $VMDiskSize
    SwitchName = "External"
    BootDevice = "CD"
}

New-VM @params

#
# We need to set the processor count and memory for the VM
Set-VM -Name $VMName -ProcessorCount 4 -StaticMemory -MemoryStartupBytes 4000000000

#
# We need to attach the ISO to the VM
Set-VMDvdDrive -VMName $VMName -Path "E:\ISO\en_windows_10_multiple_editions_version_1703_updated_july_2017_x64_dvd_10925340.iso"

#
# We can start the VM

Start-VM -Name $VMName