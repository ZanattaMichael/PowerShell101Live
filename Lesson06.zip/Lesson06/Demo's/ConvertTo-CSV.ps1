#
# Convert To CSV

Get-Process | ConvertTo-CSV

#
# Export as CSV

Get-Process | Export-CSV -Path ".\ConvertToCSV.demo.csv"
