## Get-Member  Demo

$DateofWeek = Get-Date

# Run Get Member to See the Info
$DateofWeek | Get-Member

#
# Let's Look at DateTime
$DateofWeek.DateTime | Get-Member


