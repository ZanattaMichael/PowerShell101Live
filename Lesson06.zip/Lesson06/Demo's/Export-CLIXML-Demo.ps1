#
# Export CliXML

# Show the Type of the Get-Process Object
Get-Process | Get-Member
# Export to CliXML
Get-Process | Export-Clixml -Path  ".\CliXMLExport-Demo.clixml"

#
# Import the CliXML

$clixml = Import-Clixml -Path ".\CliXMLExport-Demo.clixml"
# Show the Type 
$clixml | Get-Member
