
#
# Variables in Action
#

$MyVar = "This is a Variable"
$Var = "C:\Windows\System32"

# Put this into a method
$Result = $MyVar.Replace(" a ", " $var ")

#
# Static Method
[String]::IsNullOrEmpty("HELLO WORLD")

#
# Non-Static Method

$STRING = "THIS IS A STRING"
$STRING.Replace("STRING", "HELLO")

#
# Create an Event in PowerShell
#

# Timer Event
$timer = New-Object timers.timer
# Set our Interval
$timer.Interval = 1000
# Create an Event Subscription
Register-ObjectEvent -InputObject $timer -EventName Elapsed -SourceIdentifier Timer.Output -Action {
    Write-Host "1 Second has Passed"
}
# Enable the Event
$Timer.Enabled = $true
# Disable the Event
$timer.Enabled = $false

#
# Setting and Getting a Property
#

#Create an Object in PowerShell
$Object = New-Object -TypeName psobject
$Object | Add-Member -MemberType NoteProperty -Name "TEST" -Value ""
# Set the Property
$Object.Test = "Hello World!"
# Get the Property
$Object.Test
# Let's Clear it!
$Object.Test = ""

#
# Show a Collection of Objects
#

$Collection = Get-Process

# Index into Each Object
# Get the First 1
$Collection[0]
# Get the Second 1
$Collection[1]
# Get the Last 1
$Collection[-1]

#
# Overloading
#

# Create a String
$String = "This is a String"
# Use the SubString Method
$String.Substring(1)
# OverLoad it
$String.Substring(1,3)
