
#
# This is a Strongly Typed String Type
[String] $String = "This is a String"

# Stongly Typed Integer. Will fail.
[int] $int = "This is a String"

#
# Creating Objects

# No 1:

# Create Object
$Object = New-Object -TypeName psobject
# Add Property
$Object | Add-Member -MemberType NoteProperty -Name Property -Value "Hello World!"
# Get the Property
$Object.Property
# Change the Property Value
$Object.Property = "This is me! Life should be, fun for everyone!"


# No 2:

$Object = [PSCustomObject]@{
	PropertyName = "Value"
}
# Get the Property
$Object.PropertyName
# Change the Property Value
$Object.PropertyName = "This is me! Life should be, fun for everyone!"

# No 3:

$Object = [PSObject]::New()
# Add Property
$Object | Add-Member -MemberType NoteProperty -Name Property -Value "Hello World!"
# Get the Property
$Object.Property
# Change the Property Value
$Object.Property = "This is me! Life should be, fun for everyone!"


# No 4:

$Object = Get-Process | Select-Object -Property Name, Id -First 1
# Get them
$Object.Id
$Object.Name

#
# Creating a HashTable

$HashTable = @{
	Key = "Item"
	Michael = "Hello World!"
}

#
# Splatting
$params = @{
	Name = "YourPhone"
}
Get-Process @params
Get-Process -Name YourPhone

#
# Creating an Array / Collection in PowerShell

$arr = 1,2,3,4,5,6,7
$arr = @(1,2,3,4,5,6)
$arr.Count

# Index into an Array
$arr[0]

# Strongly Typed Array that Fails
[int32[]] $arr = @(1,2,3,4,5,6,7,9, "string")

# Strongly Typed Array that Succeeds
[int32[]] $arr = @(1,2,3,4,5,6,7,9)
$arr.Count

# Create a Empty Array
$arr = @()
$arr.Count
# Add to the Array
$arr += 1
$arr.Count

#
# Creating a Class in PowerShell

Class Test {
	[String]$Property = "Hello World"
	[String]$EmptyProperty

	# Constructor
	Test() {
		Write-Host $this.Property
	}
	# Overloaded
	Test ([Int]$custom) {
		Write-Host $custom
	}
	# Method
	Method() {
		Write-Host "This is a method"
	}
}

# Create the Object
$obj = [Test]::new()
$obj = [Test]::new("This is a custom message")
$obj.Method()
