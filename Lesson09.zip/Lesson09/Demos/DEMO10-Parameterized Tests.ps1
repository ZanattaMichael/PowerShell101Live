#
# Demo 10: Parameterized Tests
#

# Let's Take Multiply-Somthing and refactor the test to be parameterized.

function Multiply-Something() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [Double]
        $Number1,
        [Parameter(Mandatory)]
        [Double]
        $Number2,
        [Parameter()]
        [Double]
        $Number3
    )

    if ($Number3) { return ($Number1 * $Number2 * $Number3) }
    return ($Number1 * $Number2)

}

# Give the Describe Block Somthing Meaningful

Describe "Testing Multiply-Something" {

    # Let's define our Paramters according to the following standard:
    # @{ParametersToInput}, [Double]ExpectedResult
    $Parameters = @(
        @{
            Description = "Testing Positive Numbers"
            Params = @{Number1 = 1; Number2 = 2};
            Result = 2
        },
        @{
            Description = "Testing Positive & Negative Numbers"
            Params = @{Number1 = -1; Number2 = 2};
            Result = -2
        },
        @{
            Description = "Testing Negative Numbers"
            Params = @{Number1 = -2; Number2 = -2};
            Result = 4
        },
        @{
            Description = "Testing Negative Numbers with -Number3"
            Params = @{Number1 = -2; Number2 = -2; Number3 = -3};
            Result = -12
        },
        @{
            Description = "Testing Positive Numbers with -Number3"
            Params = @{Number1 = 2; Number2 = 2; Number3 = 3};
            Result = 12
        },
        @{
            Description = "Testing Positive & Negative Numbers with -Number3"
            Params = @{Number1 = 2; Number2 = -2; Number3 = 1};
            Result = -4
        }        
    )

    #
    # Let's Use ForEach to Iterate Through Each of the Items

    ForEach ($Parameter in $Parameters) {

        # We will now define the Context block within the foreach statment.
        # Remember each parameter is a test group
        Context $Parameter.Description {

            #
            # Arrange
            
            # Declare the Parameters
            $Params = $Parameter.Params

            #
            # Act

            # We an splat the paramters declared in the paramters
            $Result = Multiply-Something @Params

            #
            # Assert
            it ("Should equal '{0}'" -f $Parameter.Result) {
                $Result | Should be $Parameter.Result
            }

        }

    }

}

#
# So what do we do now? We need to fail the test to make sure it's working correctly!

# Change Result to incorrect numbers