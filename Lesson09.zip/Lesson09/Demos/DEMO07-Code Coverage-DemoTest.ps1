
# Note that we can having multiple tags associated.
Describe "Testing Read-Choice" -Tag Unit, Choice {

    Context "Testing Standard Execution" {

        #
        # Arrange
        
        # Let's mock write-host. We don't need anything printed to the screen
        Mock -CommandName Write-Host
        # Let's mock read-host. Note that we are using "TEST" as our response
        # This makes it easy for the reader to understand. We are not using any fancy input
        # Remember keep it simple!
        Mock -CommandName Read-Host -MockWith { return "TEST" }

        #
        # Act

        # We are now invoking the command 
        $Result = Read-Choice -Message "TEST" -ExpectedResult "TEST"

        #
        # Assert
        it "Should Return 'TEST'" {
            $Result | Should be "TEST"
        }
        # Since we didn't specify '-HelpMessage' we can assert that Write-Host should of not been called
        it "Should not of called Write-Host" {
            Assert-MockCalled -CommandName "Write-Host" -Exactly 0
        }
        it "Should not of called Read-Host" {
            Assert-MockCalled -CommandName "Read-Host" -Exactly 1
        }        

        # Now in the practices of this test we need to fail the test
        # Let's do that by changing the mock value

        #Mock -CommandName Read-Host -MockWith { return "FAILTEST" }
        # Now this produced a terminating error within the context block.
        # The reason why is becuase it was mocking a non expected result and it retried to the limit

    }

    Context "Testing Standard Execution with -HelpMessage" {

        #
        # Arrange
        
        # Let's mock write-host. We don't need anything printed to the screen
        Mock -CommandName Write-Host
        # Since we need to test the !? code execution path we will mock Read-Host to return
        # the required input to enter that path.
        Mock -CommandName Read-Host -MockWith { return "!?" }

        #
        # Act

        #
        # Assert
        it "Should Thrown Terminating Error" {
            # Notice that we are invoking the function within the IT block
            # This is a requirement of using Should Throw
            { Read-Choice -Message "TEST" -ExpectedResult "TEST" -HelpMessage "HELPMESSAGE" } | Should Throw "Read-Choice exceeded acceptable limit."
        }
        it "Should of called Write-Host" {
            Assert-MockCalled -CommandName "Write-Host" -Times 1
        }
        it "Should of called Read-Host" {
            Assert-MockCalled -CommandName "Read-Host" -Times 1
        }
        # Let's validate the test by failing the test. We can do this by inputting a valid value in the mock
        # that is expected
        #Mock -CommandName Read-Host -MockWith { return "TEST" }

    }

    Context "Testing Standard Execution with -DefaultValue" {

        #
        # Arrange
        
        # Let's mock write-host. We don't need anything printed to the screen
        Mock -CommandName Write-Host
        # We are now going to enter in nothing. We are wanting to test that the
        # code assigns the default value here
        Mock -CommandName Read-Host -MockWith { return "" }

        #
        # Act

        # We are now invoking the command 
        $Result = Read-Choice -Message "TEST" -ExpectedResult "TEST" -DefaultValue "TEST"

        #
        # Assert
        it "Should Return 'TEST'" {
            $Result | Should be "TEST"
        }
        # Since we didn't specify '-HelpMessage' we can assert that Write-Host should of not been called
        it "Should not of called Write-Host" {
            Assert-MockCalled -CommandName "Write-Host" -Exactly 0
        }
        it "Should not of called Read-Host" {
            Assert-MockCalled -CommandName "Read-Host" -Exactly 1
        }
        # Now in the practices of this test we need to fail the test
        # Let's do that by changing the asseration
        #$Result | Should be "TEST2"

    }

    Context "Testing Invalid Input" {

        #
        # Arrange
        
        # Let's mock write-host. We don't need anything printed to the screen
        Mock -CommandName Write-Host
        # Since we need to test the !? code execution path we will mock Read-Host to return
        # the required input to enter that path.
        Mock -CommandName Read-Host -MockWith { return "INVALID" }

        #
        # Act

        #
        # Assert
        it "Should Thrown Terminating Error" {
            { Read-Choice -Message "TEST" -ExpectedResult "TEST" -RetryCountLimit 3 } | Should Throw "Read-Choice exceeded acceptable limit."
        }
 
        # Let's validate the test by failing the test. We can do this by inputting a valid value in the mock
        # that is expected
        #Mock -CommandName Read-Host -MockWith { return "TEST" }

    }    

}
