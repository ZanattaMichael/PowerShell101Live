#
# Writing a Good Unit Test!
#

# Let's use the same unit tests from Demo 03

# Demo 1: Basic Function to add somthing

function Multiply-Something() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [Double]
        $Number1,
        [Parameter(Mandatory)]
        [Double]
        $Number2,
        [Parameter()]
        [Double]
        $Number3
    )

    if ($Number3) { return ($Number1 * $Number2 * $Number3) }
    return ($Number1 * $Number2)

}

#
# Let's apply the principals of writing a good test here
#
# Firstly note that there are two execution paths. This means two tests!

# Let's ensure that our describe block is meaningful
# Note that I am also tagging the test using the -Tag Paramter
# When we invoke a series of tests using Invoke-Pester we can specify which tests to execute.

Describe "Testing Multiply-Something" -Tag Unit {

    # Let's describe the code execution path
    Context "Number1 and Number2 Paramters" {

        #
        # Arrange

        #
        # Act
        $result = Multiply-Something -Number1 1 -Number2 2

        #
        # Assert
        It "Should Equal 2" {
            $result | Should be 2
        }
    }

    Context "Number1, Number2 & Number3 Paramters" {

        #
        # Arrange

        #
        # Act
        $result = Multiply-Something -Number1 1 -Number2 2 -Number3 2

        #
        # Assert
        It "Should Equal 4" {
            $result | Should be 4
        }        
    }

}

#
# Let's go ahead and run it!
# Huzzah it passed!
# However before we move on we need to make sure the test is working correctly.
# Now we need to manually fail the test
#
#It "Should Equal 4" {
#    $result | Should be 3
#}  

# We can see it fails we have a good test! Let's continue!
# Also note that when reviewing the results, it's easy and meaningful
# Ok let's write another unit tests where we need to mock somthing!

#
# Demo 03a: Mocking Unit Test
#

# This function is slightly more complicated. We will need to write a few unit tests here!

function Read-Choice {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [String]
        $Message,
        [Parameter(Mandatory)]
        [String[]]
        $ExpectedResult,
        [String]
        $HelpMessage,
        [String]
        $DefaultValue,
        [Int]
        $RetryCountLimit = 10
    )

    $RetryCount = 0

    # Append the Default Value to the Message
    if (-not([String]::IsNullOrEmpty($DefaultValue))) {
        $Message = "{0} (Default: {1})" -f $Message, $DefaultValue
    }
    # Append the Default Value to the Message
    if (-not([String]::IsNullOrEmpty($HelpMessage))) {
        $Message = "{0} (!? for Help)" -f $Message
    }			

    Do {			
        # Prompt the user for Input
        $Prompt = Read-Host -Prompt $Message

        if ($Prompt -eq "!?") {
            if (-not([String]::IsNullOrEmpty($HelpMessage))) {
                Write-Host $HelpMessage
            }
        } elseif ($Prompt -eq "") {
            $Prompt = $DefaultValue
        }

        $RetryCount++
    
    } Until (($Prompt -in $ExpectedResult) -or ($RetryCount -gt $RetryCountLimit))

    # If the Retry Counter Exceeds the Limit. Throw a Terminating Error
    if ($RetryCount -gt $RetryCountLimit) {
        Throw "Read-Choice exceeded acceptable limit."
    }

    Write-Output $Prompt

}


#
# In this function. There are 4 Execution Paths
# 1: Standard Execution with the Mandatory parameters (-Message and -ExpectedResult)
# 2: Standard Execution with the Mandatory parameters (-Message and -ExpectedResult) and -HelpMessage
# 3: Standard Execution with the Mandatory parameters (-Message and -ExpectedResult) and -DefaultValue
# 4: Failing Test with an Invalid Input (we can also specify the RetryCountLimit)

# In this test we are going to lean about some other ways we can test functionality
# These are Assert-MockCalled
# Should Throw

# One thing to note is that when

# Note that we can having multiple tags associated.
Describe "Testing Read-Choice" -Tag Unit, Choice {

    Context "Testing Standard Execution" {

        #
        # Arrange
        
        # Let's mock write-host. We don't need anything printed to the screen
        Mock -CommandName Write-Host
        # Let's mock read-host. Note that we are using "TEST" as our response
        # This makes it easy for the reader to understand. We are not using any fancy input
        # Remember keep it simple!
        Mock -CommandName Read-Host -MockWith { return "TEST" }

        #
        # Act

        # We are now invoking the command 
        $Result = Read-Choice -Message "TEST" -ExpectedResult "TEST"

        #
        # Assert
        it "Should Return 'TEST'" {
            $Result | Should be "TEST"
        }
        # Since we didn't specify '-HelpMessage' we can assert that Write-Host should of not been called
        it "Should not of called Write-Host" {
            # We will use the Assert-MockCalled.
            # Since we are mocking Write-Host we can measure the number of times that
            # Write-Host is called. In this instance it should be 0 times.
            Assert-MockCalled -CommandName "Write-Host" -Exactly 0
        }

        # Now in the practices of this test we need to fail the test
        # Let's do that by changing the mock value

        #Mock -CommandName Read-Host -MockWith { return "FAILTEST" }
        # Now this produced a terminating error within the context block.
        # The reason why is becuase it was mocking a non expected result and it retried to the limit

    }

    Context "Testing Standard Execution with -HelpMessage" {

        #
        # Arrange
        
        # Let's mock write-host. We don't need anything printed to the screen
        Mock -CommandName Write-Host
        # Since we need to test the !? code execution path we will mock Read-Host to return
        # the required input to enter that path.
        Mock -CommandName Read-Host -MockWith { return "!?" }

        #
        # Act

        #
        # Assert
        it "Should Thrown Terminating Error" {
            # Notice that we are invoking the function within the IT block
            # This is a requirement of using Should Throw
            { Read-Choice -Message "TEST" -ExpectedResult "TEST" -HelpMessage "HELPMESSAGE" } | Should Throw "Read-Choice exceeded acceptable limit."
        }
        # Since 
        it "Should of called Write-Host" {
            # This time we are going to assert that Write-Host was called more then once.
            # We will use the -Times parameter
            Assert-MockCalled -CommandName "Write-Host" -Times 1
        }

        # Let's validate the test by failing the test. We can do this by inputting a valid value in the mock
        # that is expected
        #Mock -CommandName Read-Host -MockWith { return "TEST" }

    }

    Context "Testing Standard Execution with -DefaultValue" {

        #
        # Arrange
        
        # Let's mock write-host. We don't need anything printed to the screen
        Mock -CommandName Write-Host
        # We are now going to enter in nothing. We are wanting to test that the
        # code assigns the default value here
        Mock -CommandName Read-Host -MockWith { return "" }

        #
        # Act

        # We are now invoking the command 
        $Result = Read-Choice -Message "TEST" -ExpectedResult "TEST" -DefaultValue "TEST"

        #
        # Assert
        it "Should Return 'TEST'" {
            $Result | Should be "TEST"
        }
        # Since we didn't specify '-HelpMessage' we can assert that Write-Host should of not been called
        it "Should not of called Write-Host" {
            Assert-MockCalled -CommandName "Write-Host" -Exactly 0
        }

        # Now in the practices of this test we need to fail the test
        # Let's do that by changing the asseration
        #$Result | Should be "TEST2"

    }

    Context "Testing Invalid Input" {

        #
        # Arrange
        
        # Let's mock write-host. We don't need anything printed to the screen
        Mock -CommandName Write-Host
        # Since we need to test the !? code execution path we will mock Read-Host to return
        # the required input to enter that path.
        Mock -CommandName Read-Host -MockWith { return "INVALID" }

        #
        # Act

        #
        # Assert
        it "Should Thrown Terminating Error" {
            { Read-Choice -Message "TEST" -ExpectedResult "TEST" -RetryCountLimit 3 } | Should Throw "Read-Choice exceeded acceptable limit."
        }
 
        # Let's validate the test by failing the test. We can do this by inputting a valid value in the mock
        # that is expected
        #Mock -CommandName Read-Host -MockWith { return "TEST" }

    }    

}

#
# This concludes this Demo!