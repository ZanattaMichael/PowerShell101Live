#
# Demo 01: Basic Test Syntax:
#

#
# This is a Pester Test file. Note that it's powershell
# A few things to remember:
# Keep your Tests and Code Seperate.
# Pester Test Files should end in: *.tests.ps1

#
# Remember this Describe, Context & It are just groups.

Describe "Test Groups Group" {

    Context "Test Group 1" {

        # Arrange
        $var = 1
        # Act
        
        # Assert
        It "Test 01" {
            # Forget this, we will cover this.
            $var | Should be 2
        }
    }

    Context "Test Group 2" {

        # Arrange
        $var = 2
        # Act
        
        # Assert
        It "Test 01" {
            # Forget this, we will cover this.
            $var | Should be 2
        }
    }    
}

#
# Demo 01a: 
#           If there is one test group, you can exclude the context block and nest the tests
#           in the describe block.
#
#       Important Note: The scope of the execution remaines within the context of the scriptblocks
#                       Aka: Scriptblock variable scoping rules apply here!

Describe "Test" {

    # Arrange
    $var = 1

    # Act

    # Assert
    It "Test 01" {
        # Forget this, we will cover this.
        $var | Should be 2
    }
}

#
# Demo 01b: 
#           Using the AAA approch lets explore each of the 
#           A: Arrange
#           A: Act
#           A: Assert
#           in the describe block.

# Ignore this function
function Add-Somthing() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [Double]
        $Number1,
        [Parameter(Mandatory)]
        [Double]
        $Number2        
    )

    return ($Number1 + $Number2)

}

#
# When we write the Test Name Here (Since we are not using a context block)
Describe "AAA Explanation" {

    #
    # Arrange

    # Within the Arrange Block, we setup the test.
    # Similarly to a script where you would setup constents at the top of the script.
    # Here you would setup your test (Mocks, Varaiables, FilePaths)
    
    $Number1 = 1
    $Number2 = 2

    #
    # Act
    
    # Here we are invoke the action that we are wanting to achive
    # This looks normal. Here we are testing this function by calling Add-Function
    $result = Add-Somthing -Number1 $Number1 -Number2 $Number2

    #
    # Assert

    # Here we are "asserting it response".
    # The IT block will test a single facet of the code. You can have multiple IT blocks.
    # We are testing a single result in this test.

    # When writing it's response, we write somthing that the user can understand.
    # Remember this get's printed to the user.
    # This is a passing test!
    It "Should equal 3" {
        
        # Note we are piping the output to the cmdlet should.
        # The should cmdlet allows you to test the action, allowing you to assert.
        # https://github.com/pester/Pester/wiki/Should
        $result | Should be 3
    }
}

#
# Demo 01c: Multiple Tests
#
# Now Using the Same Function Add-Somthing, multiple tests are needed.
# Why is that? Becuase we need to validate that it can add multiple types of numbers
# They are: Postive Numbers, Negative Numbers, Positive & Negative Numbers & Decimals
# Let's give it a go

# Let's describe what we are testing
Describe "Testing Add-Somthing" {

    # Let's define what our first context block will be
    Context "Positive Numbers" {

        #
        # Arrange

        # 
        # Act
    
        # Note that we are parsing the value directly into the function.
        # This is normal.
        $result = Add-Somthing -Number1 1 -Number2 2

        #
        # Assert
        It "Should equal 3" {
            $result | Should be 3
        }

    }
    Context "Negative Numbers" {

        #
        # Arrange        

        # 
        # Act

        # Note that we are parsing the value directly into the function.
        # This is normal.
        $result = Add-Somthing -Number1 -1 -Number2 -2

        #
        # Assert
        It "Should equal -3" {
            $result | Should be -3
        }
        
    }
    Context "Positive & Negative Numbers" {

        #
        # Arrange

        # 
        # Act

        # Note that we are parsing the value directly into the function.
        # This is normal.
        $result = Add-Somthing -Number1 -1 -Number2 1

        #
        # Assert
        It "Should equal 0" {
            $result | Should be 0
        }

    }
    Context "Decimals Numbers" {

        # 
        # Act

        #
        # Arrange

        # Note that we are parsing the value directly into the function.
        # This is normal.
        $result = Add-Somthing -Number1 1.5 -Number2 1.5

        #
        # Assert
        It "Should equal 3" {
            $result | Should be 3
        }
        
    }
}

#
# Let's run it and go though the results!
# Note the result from Decimals Numbers. This function is outputting 4, while it should output 3
# We have caught a failing test!

# Firstly let's debug this. Pester tests can be debugged so you can see what's going on
# Place Breakpoint on line 199 and step in.

# The reason why this is happening is PowerShell is rounding up to 2
# So let's fix it!
# We need to change the input paramters to be [Double] (Supports decimals)

#
# This Concludes this Demo!

#
# Demo 01d: Running Pester in PowerShell
#

# To run a pester script use the Invoke-Pester cmdlet

# Get-Help Invoke-Pester -Full
#Invoke-Pester -Script "FILENAME"

Invoke-Pester -Script ".\DEMO03-Writing a Basic Unit Test.ps1"

