#
# Demo 08: Scenario 08
# Let's write unit tests for Get-UrlLinks 
#


Function Format-AbsoluteUrl {
    Param(
        $Url,
        $ParentUrl
    )

    # Test for Relitive Path    
    if (($Url -notlike "http://*") -and ($Url -notlike "https://*")) {
        # Append the Url to the Relitive Path
        Write-Output ("{0}{1}" -f $ParentUrl, $_)
    } else {
        Write-Output $_
    }

}

Function Get-ChildUrl () {
    [CmdletBinding()]
    param (
        [Parameter()]
        [PSCustomObject]
        $EnumeratedLinks
    )


    # Now it's time to iterate through each of the Links and Call the Respective Url
    $ChildUrls = $EnumeratedLinks | ForEach-Object { 
        (Invoke-WebRequest -Uri $_).Links.Href
    }

    Write-Output $ChildUrls

}

function Get-AbsoluteURL {
    [CmdletBinding()]
    param (
        [Parameter()]
        [String[]]
        $CombinedLinks
    )

    $CombinedLinks | ForEach-Object {
        
        # Test for Relitive Path
        $CustomObject = [PSCustomObject]@{
            OriginalUrl = $Url
            EnumeratedUrl = Format-AbsoluteUrl -Url $_ -ParentUrl $Url
        }
    
        # Return to the Pipeline
        Write-Output $CustomObject
    }

}

Function Get-UrlLinks {
    Param(
        $Url
    )
    
    # Create a Variable Called Request
    $Request = Invoke-WebRequest -Uri $Url
    # We need to append the Url to the Relitive Paths, ignoring absolute paths
    $EnumeratedLinks = $Request.Links.Href | ForEach-Object { Format-AbsoluteUrl -Url $_ -ParentUrl $Url }
    
    # Now it's time to iterate through each of the Links and Call the Respective Url
    $ChildUrls = Get-ChildUrl -EnumeratedLinks $EnumeratedLinks
    
    # Combine the Links
    $CombinedLinks = @()
    $CombinedLinks += $EnumeratedLinks
    $CombinedLinks += $ChildUrls
    
    # We now need to create absolute Url paths
    $Links = Get-AbsoluteURL -CombinedLinks $CombinedLinks
    
    # Return the Combined Links to the Caller
    Write-Output $Links   

}

#
# Pester Tests

Describe "Testing Get-UrlLinks" -Tag Unit {

    Context "Standard Execution" {

        #
        # Arrange
        Mock -CommandName Invoke-WebRequest -MockWith { return (Import-Clixml -Path '.\DemoMocks\Invoke-WebRequest.mock.xml')}
        Mock -CommandName Format-AbsoluteUrl -MockWith { return (Import-Clixml -Path '.\DemoMocks\Format-AbsoluteUrl.mock.xml') }
        Mock -CommandName Get-ChildUrl -MockWith { return (Import-Clixml -Path '.\DemoMocks\Get-ChildUrl.mock.xml') }
        Mock -CommandName Get-AbsoluteUrl -MockWith { return (Import-Clixml -Path '.\DemoMocks\Get-AbsoluteURL.mock.xml') }

        #
        # Act
        
        $result = Get-UrlLinks -Url "TEST"

        #
        # Assert

        it "Should of Called Invoke-WebRequest" {
            Assert-MockCalled -CommandName Invoke-WebRequest -Exactly 1
        }
        it "Should of Called Format-AbsoluteUrl" {
            Assert-MockCalled -CommandName Format-AbsoluteUrl -Times 1
        }
        it "Should of Called Get-ChildUrl" {
            Assert-MockCalled -CommandName Get-ChildUrl -Exactly 1
        }
        it "Should of Called Get-AbsoluteURL" {
            Assert-MockCalled -CommandName Get-AbsoluteURL -Exactly 1
        }
        it "Output should Contain PowerShell Objects (OriginalUrl, EnumeratedUrl)" {
            $result.OriginalUrl | Should not be $null
            $result.EnumeratedUrl | Should not be $null
        }

    }

    Context "Invalid URL" {

        #
        # Arrange
        Mock -CommandName Invoke-WebRequest -MockWith { return Throw "ERROR"}
        Mock -CommandName Format-AbsoluteUrl -MockWith { return (Import-Clixml -Path '.\DemoMocks\Format-AbsoluteUrl.mock.xml') }
        Mock -CommandName Get-ChildUrl -MockWith { return (Import-Clixml -Path '.\DemoMocks\Get-ChildUrl.mock.xml') }
        Mock -CommandName Get-AbsoluteUrl -MockWith { return (Import-Clixml -Path '.\DemoMocks\Get-AbsoluteURL.mock.xml') }

        #
        # Act
        
        #
        # Assert

        it "Should Throw Terminating Error" {
            { Get-UrlLinks -Url "TEST" } | Should Throw
        }
        it "Should of Called Format-AbsoluteUrl" {
            Assert-MockCalled -CommandName Format-AbsoluteUrl -Exactly 0
        }
        it "Should of Called Get-ChildUrl" {
            Assert-MockCalled -CommandName Get-ChildUrl -Exactly 0
        }
        it "Should of Called Get-AbsoluteURL" {
            Assert-MockCalled -CommandName Get-AbsoluteURL -Exactly 0
        }

    }

    Context "Standard Execution - No Child Urls" {

        #
        # Arrange
        Mock -CommandName Invoke-WebRequest -MockWith { return (Import-Clixml -Path '.\DemoMocks\Invoke-WebRequest.mock.xml')}
        Mock -CommandName Format-AbsoluteUrl -MockWith { return (Import-Clixml -Path '.\DemoMocks\Format-AbsoluteUrl.mock.xml') }
        Mock -CommandName Get-ChildUrl
        Mock -CommandName Get-AbsoluteUrl -MockWith { return (Import-Clixml -Path '.\DemoMocks\Get-AbsoluteURL.mock.xml') }

        #
        # Act
        
        $result = Get-UrlLinks -Url "TEST"

        #
        # Assert

        it "Should of Called Invoke-WebRequest" {
            Assert-MockCalled -CommandName Invoke-WebRequest -Exactly 1
        }
        it "Should of Called Format-AbsoluteUrl" {
            Assert-MockCalled -CommandName Format-AbsoluteUrl -Times 1
        }
        it "Should of Called Get-ChildUrl" {
            Assert-MockCalled -CommandName Get-ChildUrl -Exactly 1
        }
        it "Should of Called Get-AbsoluteURL" {
            Assert-MockCalled -CommandName Get-AbsoluteURL -Exactly 1
        }
        it "Output shouldn't contain PowerShell Objects (OriginalUrl, EnumeratedUrl)" {
            $result.OriginalUrl | Should not be $null
            $result.EnumeratedUrl | Should not be $null
        }

    }

    Context "Standard Execution - Remove Get-AbsoluteUrl" {

        #
        # Arrange
        Mock -CommandName Invoke-WebRequest -MockWith { return (Import-Clixml -Path '.\DemoMocks\Invoke-WebRequest.mock.xml')}
        Mock -CommandName Format-AbsoluteUrl -MockWith { return (Import-Clixml -Path '.\DemoMocks\Format-AbsoluteUrl.mock.xml') }
        Mock -CommandName Get-ChildUrl
        Mock -CommandName Get-AbsoluteUrl

        #
        # Act
        
        $result = Get-UrlLinks -Url "TEST"

        #
        # Assert

        it "Should of Called Invoke-WebRequest" {
            Assert-MockCalled -CommandName Invoke-WebRequest -Exactly 1
        }
        it "Should of Called Format-AbsoluteUrl" {
            Assert-MockCalled -CommandName Format-AbsoluteUrl -Times 1
        }
        it "Should of Called Get-ChildUrl" {
            Assert-MockCalled -CommandName Get-ChildUrl -Exactly 1
        }
        it "Should of Called Get-AbsoluteURL" {
            Assert-MockCalled -CommandName Get-AbsoluteURL -Exactly 1
        }
        it "Output shouldn't contain anything" {
            $result | Should be $null
        }

    }

}

