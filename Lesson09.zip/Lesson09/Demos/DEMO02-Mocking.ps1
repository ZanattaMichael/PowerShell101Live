#
# Demo 01: Basic Mock Syntax:
#

# URL: https://github.com/pester/Pester/wiki/Mock

Describe "Test Groups Group" {

    Context "Test Group 1" {

        #
        # Arrange

        $var = 1
        # Mocks performed within the Arrange Segment of the code
        # Let's mock Write-Host to return 1
        # Remember we are "emulating" the action. We are not performing it.
        Mock -CommandName Write-Host -MockWith { return "1" }
        # Let's break it down:
        # Command Name: The name of the command to be mocked.
        # MockWith: A ScriptBlock specifying the behavior that will be used to mock CommandName. 
        #           The default is an empty ScriptBlock.
        
        # If we want to mock nothing, we can exclude MockWith
        #Mock -CommandName Write-Host

        #
        # Act
        
        #
        # Assert
        It "Test 01" {
            $var | Should be 2
        }
    }
 
}

#
# Demo 01a: Practical Mock Syntax:
#

# Let's head back to Add-Somthing
# This time we are going to read a CSV
function Add-Somthing() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateScript({
            Test-Path -LiteralPath $_
        })]
        [String]
        $CSVPath        
    )

    $CSV = Import-CSV -LiteralPath $CSVPath

    return ($CSV.Number1 + $CSV.Number2)

}

# Firstly let's review the function.
# Note that we have two cmdlet's that we need to mock
# The First is Import-CSV. This is quite obvious
# The Second and more sutble is Test-Path within the script validation. We will need to mock this as well,
# since the path we are inputting will be incorrect.

Describe "Testing Add-Somthing" {

    # Let's only focus on the positive number test set
    # Let's define what our first context block will be
    Context "Positive Numbers" {

        # 
        # Act

        # Let's Mock Test-Path to always return true.
        # Since we will be giving it a phoney path, we need it to be true
        Mock -CommandName Test-Path -MockWith { return $true }
        # Let's Mock Import-CSV.
        Mock -CommandName Import-CSV -MockWith {
            [PSCustomObject]@{
                Number1 = 1
                Number2 = 2
            }
        }
        # Now let's say you have a large CSV file. You don't have to manually construct the object structure
        # and you can import mock data. For instance:
        #Mock -CommandName Import-CSV -MockWith { Import-CSV -Path .\MockCSV.csv }
        # This also applies if you want to import test data/ production data from to test with. Very handy.

        #
        # Arrange

        # Note we are parsing a phony string into the file.
        $result = Add-Somthing -CSVPath "TEST"

        #
        # Assert
        It "Should equal 3" {
            $result | Should be 3
        }

    }
}

# Let's run this! You can see it's a success! Huzzah!

