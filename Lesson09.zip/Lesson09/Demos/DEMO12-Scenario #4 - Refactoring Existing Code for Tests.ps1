#
# Demo 13: Refactoring Existing Code for Testing
#
#
# The Function Below is using a live function that I have written and needs to be refactored
#
# We need refactor this code to be optimised for testing
# So let's look at the issues
# 1: The code block can be simplified. A check is being peformed with numbers divisiable by 0
# 2: Multiple Read-Hosts for different values. Mocking can't be done here.
# 3: How can we test a failing read-host value in one of the inputs? This would create an
#   infinate loop. We will need to fix that.

Function DoMath {
    [CmdletBinding()]
    param (
        [Parameter()]
        [Int]
        $Number1=0,
        [Parameter(Mandatory)]
        [ValidateSet("+","-","*","/","^","%")]
        [String]
        $Operator,
        [Parameter()]
        [Int]
        $Number2=0
    )

    # If Number 1 and Number 2 are 0 and the operator is /, throw an error
    if ((($Number1 -eq 0) -or ($Number2 -eq 0)) -and (($Operator -eq "/") -or ($Operator -eq "%"))) {
        Write-Error "Number cannot be divisable by 0"
        Do {
            $Number1 = Read-Host "Enter in Number1"
            $Number2 = Read-Host "Enter in Number2"
        } Until ($Number1 -and $Number2)
    } else {
        Switch ($Operator) {
            "+" { $result = $Number1 + $Number2 }
            "-" { $result = $Number1 - $Number2 }
            "*" { $result = $Number1 * $Number2 }
            "/" { $result = $Number1 / $Number2 }
            "^" { $result = [Math]::Pow($Number1, $Number2) }
            "%" { $result = $Number1 % $Number2 }
        }
    }

    Write-Output $result

}

#
# UPDATED FUNCTION BELOW
#

Function Get-Number1 {

    $ref = 0
    $retryCounter = 0

    Do {
        $Number1 = Read-Host "Enter in Number1"
        $retryCounter++
    } Until (([Double]::TryParse($Number1, [ref]$ref)) -or ($retryCounter -gt 10))    

    if ($retryCounter -gt 10) { Throw "Invalid Input!" }

    Write-Output $ref
}

Function Get-Number2 {

    $ref = 0
    $retryCounter = 0

    Do {
        $Number2 = Read-Host "Enter in Number2"
        $retryCounter++
    } Until (([Double]::TryParse($Number2, [ref]$ref)) -or ($retryCounter -gt 10))  

    if ($retryCounter -gt 10) { Throw "Invalid Input!" }

    Write-Output $ref

}

Function DoMath {
    [CmdletBinding()]
    param (
        [Parameter()]
        [Double]
        $Number1=0,
        [Parameter(Mandatory)]
        [ValidateSet("+","-","*","/","^","%")]
        [String]
        $Operator,
        [Parameter()]
        [Double]
        $Number2=0
    )

    # If Number 1 and Number 2 are 0 and the operator is / or %, write an error
    if ((($Number1 -eq 0) -or ($Number2 -eq 0)) -and ($Operator -in @("/","%"))) {
        Write-Error "Number cannot be divisable by 0"
        $Number1 = Get-Number1
        $Number2 = Get-Number2
    }

    Switch ($Operator) {
        "+" { $result = $Number1 + $Number2 }
        "-" { $result = $Number1 - $Number2 }
        "*" { $result = $Number1 * $Number2 }
        "/" { $result = $Number1 / $Number2 }
        "^" { $result = [Math]::Pow($Number1, $Number2) }
        "%" { $result = $Number1 % $Number2 }
    }

    Write-Output $result

}

#
# PESTER TESTS
#

Describe "Testing Get-NumberX" {

    $StandardExecutionParameters = @(
        @{
            context = "Testing Get-Number1 with Integer"
            scriptBlock = { Get-Number1 }
            mock = { Mock -CommandName Read-Host -MockWith { return 1 } }
            result = 1
        },
        @{
            context = "Testing Get-Number2 with Integer"
            scriptBlock = { Get-Number2 }
            mock = { Mock -CommandName Read-Host -MockWith { return 1 } }
            result = 1
        },   
        @{
            context = "Testing Get-Number1 with Double"
            scriptBlock = { Get-Number1 }
            mock = { Mock -CommandName Read-Host -MockWith { return 1.5 } }
            result = 1.5
        },
        @{
            context = "Testing Get-Number2 with Double"
            scriptBlock = { Get-Number2 }
            mock = { Mock -CommandName Read-Host -MockWith { return 1.5 } }
            result = 1.5
        }             
    )

    foreach ($Parameter in $StandardExecutionParameters) {

        Context $Parameter.context {
    
            #
            # Act
            
            # . Source the Mock
            . $Parameter.mock

            #
            # Arrange

            $result = . $Parameter.scriptBlock

            #
            # Assert
            it "Should contain $($Parameter.result)" {
                $result | Should be $Parameter.result
            }
        }

    }

    Context "Testing Get-Number1 with Invalid Input" {

        #
        # Arrange
        Mock -CommandName Read-Host

        #
        # Act

        #
        # Assert
        it "Should Throw a Terminating Error" {
            { Get-Number1 } | Should -Throw 
        }
        
    }

    Context "Testing Get-Number2 with Invalid Input" {

        #
        # Arrange
        Mock -CommandName Read-Host

        #
        # Act

        #
        # Assert
        it "Should Throw a Terminating Error" {
            { Get-Number2 } | Should -Throw 
        }
        
    }    

}


Describe "Testing DoMath" {
    
    $parameters = @(
        @{
            Context = "Testing Addition"
            Result = 2
            Params = @{Number1 = 1; Operator = "+"; Number2 = 1}
            Mock = {
                Mock -CommandName Get-Number1
                Mock -CommandName Get-Number2
            }
        },
        @{
            Context = "Testing Subtraction"
            Result = 0
            Params = @{Number1 = 1; Operator = "-"; Number2 = 1}
            Mock = {
                Mock -CommandName Get-Number1
                Mock -CommandName Get-Number2
            }            
        },
        @{
            Context = "Testing Multiplication"
            Result = 4
            Params = @{Number1 = 2; Operator = "*"; Number2 = 2}
            Mock = {
                Mock -CommandName Get-Number1
                Mock -CommandName Get-Number2
            }            
        },
        @{
            Context = "Testing Division"
            Result = 2
            Params = @{Number1 = 4; Operator = "/"; Number2 = 2}
            Mock = {
                Mock -CommandName Get-Number1
                Mock -CommandName Get-Number2
            }            
        },        
        @{
            Context = "Testing Modulus"
            Result = 1
            Params = @{Number1 = 5; Operator = "%"; Number2 = 2}
            Mock = {
                Mock -CommandName Get-Number1
                Mock -CommandName Get-Number2
            }            
        }
    )

    ForEach ($parameter in $parameters) {

        Context $parameter.Context {

            #
            # Arrange
            . $parameter.Mock
            $params = $parameter.params

            #
            # Act
            $result = DoMath @params

            #
            # Assert
            it "Should be $($parameter.result)" {
                $result | Should be $parameter.Result
            }
            it "Should of not called Get-Number1" {
                Assert-MockCalled -CommandName Get-Number1 -Exactly 0
            }


        }
    }

    Context "Testing Invalid Input with Divide" {

        #
        # Arrange
        Mock Get-Number1 -MockWith { return 4 }
        Mock Get-Number2 -MockWith { return 2 }
        Mock Write-Error

        #
        # Act
        $result = DoMath -Number1 0 -Operator "/" -Number2 0

        #
        # Assert

        it "Should return 2" {
            $result | Should be 2
        }
        it "Should of called Get-Number1" {
            Assert-MockCalled -CommandName Get-Number1 -Exactly 1
        }
        it "Should of called Get-Number2" {
            Assert-MockCalled -CommandName Get-Number2 -Exactly 1
        }
        it "Should of called Write-Error" {
            Assert-MockCalled -CommandName Write-Error -Exactly 1
        }
    }

    Context "Testing Invalid Input with Modulus" {

        #
        # Arrange
        Mock Get-Number1 -MockWith { return 5 }
        Mock Get-Number2 -MockWith { return 2 }
        Mock Write-Error

        #
        # Act
        $result = DoMath -Number1 0 -Operator "%" -Number2 0

        #
        # Assert

        it "Should return 1" {
            $result | Should be 1
        }
        it "Should of called Get-Number1" {
            Assert-MockCalled -CommandName Get-Number1 -Exactly 1
        }
        it "Should of called Get-Number2" {
            Assert-MockCalled -CommandName Get-Number2 -Exactly 1
        }
        it "Should of called Write-Error" {
            Assert-MockCalled -CommandName Write-Error -Exactly 1
        }
    }    

}

#
# Once we have refactored the code we can then write our tests.
# Will will also use parameterised testing to shorten the test suite.
#
