#
# Demo 11: Parameterised Tests - Math Function
#

# 
# Write a Parameterised Test for the Following:
function Add-Somthing() {
    [CmdletBinding(DefaultParameterSetName="CSVPath")]
    param (
        [Parameter(Mandatory, ParameterSetName="CSVPath")]
        [ValidateScript({
            Test-Path -LiteralPath $_
        })]
        [String]
        $CSVPath,
        [Parameter(Mandatory, ParameterSetName="Number")]
        [Double]
        $Number1,
        [Parameter(Mandatory, ParameterSetName="Number")]
        [Double]
        $Number2      
    )

    if ($PSCmdlet.ParameterSetName -eq "CSVPath") {
        $CSV = Import-CSV -LiteralPath $CSVPath
        return ($CSV.Number1 + $CSV.Number2)
    }

    return ($Number1 + $Number2)

}

#
# PESTER TEST

Describe "Testing Add-Somthing" -Tag Unit, Parameter {

    $parameters = @(
        @{
            Context = "Testing Positive Numbers"
            Result = 2
            Params = @{Number1 = 1; Number2 = 1}
            Mock = {}
        },
        @{
            Context = "Testing Negative Numbers"
            Result = -2
            Params = @{Number1 = -1; Number2 = -1}
            Mock = {}
        },
        @{
            Context = "Testing Positive & Negative Numbers"
            Result = 0
            Params = @{Number1 = -1; Number2 = 1}
            Mock = {}
        },
        @{
            Context = "Testing Decimal Positive Numbers"
            Result = 3
            Params = @{Number1 = 1.5; Number2 = 1.5}
            Mock = {}
        },        
        @{
            Context = "Testing CSVPath with Positive Numbers"
            Result = 2
            Params = @{CSVPath = "TEST"}
            Mock = { 
                Mock -CommandName Test-Path -MockWith {$true}
                Mock -CommandName Import-CSV -MockWith {
                    return ([PSCustomObject]@{ Number1 = 1; Number2 = 1 })
                } 
            }
        },
        @{
            Context = "Testing CSVPath with Negative Numbers"
            Result = -2
            Params = @{CSVPath = "TEST"}
            Mock = { 
                Mock -CommandName Test-Path -MockWith {$true}
                Mock -CommandName Import-CSV -MockWith {
                    return ([PSCustomObject]@{ Number1 = -1; Number2 = -1 })
                } 
            }
        },
        @{
            Context = "Testing CSVPath with Positive & Negative Numbers"
            Result = 0
            Params = @{CSVPath = "TEST"}
            Mock = { 
                Mock -CommandName Test-Path -MockWith {$true}
                Mock -CommandName Import-CSV -MockWith {
                    return ([PSCustomObject]@{ Number1 = -1; Number2 = 1 })
                }
            }
        }               
    )

    Foreach ($parameter in $parameters) {

        Context $parameter.Context {

            #
            # Arrange
            
            # Declare Parameters for Add-Somthing
            $params = $parameter.Params
            
            # Dot Source Mocks in as needed
            . $parameter.Mock

            #
            # Act

            # Splat the Items in
            $result = Add-Somthing @params

            #
            # Assert
            
            it "Should contain $($parameter.Result)" {
                $result | Should be $parameter.Result
            }

        }

    }


}

