#
# Demo 08: Scenario 08
# Let's write unit tests for divide-somthing
#

Function Divide-Something {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [Double]
        $Number1,
        [Parameter(Mandatory)]
        [Double]
        $Number2
    )

    #
    # Let's dertimine the code execution paths

    # Divisable by 0
    if ($Number1, $Number2 -contains 0) {
        # Throw Terminating Error
        Throw "Number Not Divisable By Zero"
    }

    # Divide the Numbers
    Return ($Number1 / $Number2)

}



Describe "Testing Divide-Somthing" -Tag Unit, Math {

    Context "Number Divisable By 0" {

        #
        # Arrange

        #
        # Act
        
        #
        # Assert
        It "Should throw a terminating error" {
            { Divide-Something -Number1 4 -Number2 0 } | Should Throw "Number Not Divisable By Zero"
        }

    }

    Context "Standard Exectuion" {

        #
        # Arrange

        #
        # Act
        $result = Divide-Something -Number1 4 -Number2 2

        #
        # Assert
        It "Should Equal 2" {
            $result | Should be 2
        }

    }

}