#
# Demo 04 - Let's write a basic intergration test
#

#
# Note the function Add-Stuff
# It's writing to a file
# Where a unit test would mock the value,
# an intergration test will write the file to disk.

# This presents a problem. That where do we write the file?
# How do we cleanup the file once the test is complete?
# Pester to the rescue! We can use TestDrive:\ drive
# https://github.com/pester/Pester/wiki/TestDrive
Function Write-Stuff {
    [CmdletBinding()]
    param (
        [Parameter()]
        [String]
        $FilePath,
        [Parameter()]
        [String]
        $Content
    )

    $Content | Out-File -LiteralPath $FilePath

}

# Give it a meaningfull heading
# We only have a single test group here so no need for a context block
Describe "Testing Write-Stuff" -Tag Intergration {

    #
    # Arrange
    
    # Note that we are using the "TestDrive" drive
    $Path = "TestDrive:\test.txt"

    #
    # Act

    # Invoke the function that we need to test
    Write-Stuff -FilePath $Path -Content "TEST"
    # Read the File to get it's results
    $result = Get-Content -LiteralPath $Path

    #
    # Assert

    It "Should contain 'TEST'" {
        (-join $result) | Should Be "TEST"
    }

}