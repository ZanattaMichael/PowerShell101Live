#
# Demo 07 Code Coverage
# 

#
# Let's take the Previous Demo Read-Choice

function Read-Choice {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [String]
        $Message,
        [Parameter(Mandatory)]
        [String[]]
        $ExpectedResult,
        [String]
        $HelpMessage,
        [String]
        $DefaultValue,
        [Int]
        $RetryCountLimit = 10
    )

    $RetryCount = 0

    # Append the Default Value to the Message
    if (-not([String]::IsNullOrEmpty($DefaultValue))) {
        $Message = "{0} (Default: {1})" -f $Message, $DefaultValue
    }
    # Append the Default Value to the Message
    if (-not([String]::IsNullOrEmpty($HelpMessage))) {
        $Message = "{0} (!? for Help)" -f $Message
    }			

    Do {			
        # Prompt the user for Input
        $Prompt = Read-Host -Prompt $Message

        if ($Prompt -eq "!?") {
            if (-not([String]::IsNullOrEmpty($HelpMessage))) {
                Write-Host $HelpMessage
            }
        } elseif ($Prompt -eq "") {
            $Prompt = $DefaultValue
        }

        $RetryCount++
    
    } Until (($Prompt -in $ExpectedResult) -or ($RetryCount -gt $RetryCountLimit))

    # If the Retry Counter Exceeds the Limit. Throw a Terminating Error
    if ($RetryCount -gt $RetryCountLimit) {
        Throw "Read-Choice exceeded acceptable limit."
    }

    Write-Output $Prompt

}

#Invoke-Pester -CodeCoverage "FILENAME"
Invoke-Pester -CodeCoverage ".\DEMO07-Code Coverage-DemoTest.ps1"

#
# Let's explore the output