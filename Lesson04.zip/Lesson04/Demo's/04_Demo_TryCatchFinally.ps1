#
# Default Statment

# Clear Error Variable to make things easier
$error.Clear()

Try {
    DoSOMTHING
} Catch {
    # Do Somthing in here!
    Write-Host "That's not a cmdlet buddy!"
    $var = $_

}

# Let's have a play with var
$var

# Let's also check $error
$error

#
# Try / Catch with an exception type

Try {
    DoSOMTHING
} Catch [System.Management.Automation.ErrorRecord] {
    # Do Somthing in here!
    Write-Host "That's not a cmdlet buddy!" -ForegroundColor Green
} Catch {
    Write-Host "That's somthing else!" -ForegroundColor Red
}

#
# Try / Catch / Finally
#

Try {
    DoSOMTHING
} Catch {
    Write-Host "That's not a cmdlet buddy!" -ForegroundColor Green
} Finally {
    Write-Host "Disposing" -ForegroundColor Yellow
}

#
# Try / Finally
#

Try {
    DoSOMTHING
} Finally {
    Write-Host "Disposing" -ForegroundColor Yellow
}