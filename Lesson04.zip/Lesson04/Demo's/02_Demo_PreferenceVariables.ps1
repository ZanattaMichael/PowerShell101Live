#
# Let's Print the Verbose Preference

$VerbosePreference

Write-Verbose "Hello world"

# Change the Preference to Continue

$VerbosePreference = "Continue"

Write-Verbose "Hello world"

$VerbosePreference = "SilentlyContinue"

Write-Verbose "Hello world"

#
# Let's Print the Information Preference

Write-Information "Hello"

#
# Error Action

$ErrorActionPreference = "Stop"

Write-Error "Non Temrinating Error is now terminating error"



