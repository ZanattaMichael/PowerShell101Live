#
# Grouping Expression

$var = (1  +  1) + ( 2 + 1 )

# Two way of writing this
$var = Join-Path -Path "D:\" -ChildPath "Temp"
Get-ChildItem -LiteralPath $var
# Using Grouping Expression
Get-ChildItem -LiteralPath (Join-Path -Path "D:\" -ChildPath "Temp")


#
# Subexpression

$var = $(   
            $a = 1
            if ($a -eq 1) {
                Write-Output "YES"
            } else {
                Write-Output "NO"
            }
        )

# Always use Write-Output to output to the output stream
$var = $( $a = 1; if ($a -eq 1) { Write-Output "Yes"} else { Write-Output "No" })
# Return will return nothing to the output stream
$var = $( $a = 1; if ($a -eq 1) { Return "Yes"} else { Return "No" })

#
# Static Member Operator

# Read a File
$var = [System.IO.File]::ReadAllText("D:\Temp\Demos.ps1")
# Call the New Static Method
$var = [PSCustomObject]::new()

#
# Call Operator

$string = "Get-ChildItem"

& $string

#
# Format Operator

$filepath = "C:\RandomDirectoryThatDosen'tExist"
$string = "Seaching for: {0}. Result: {1}" -f $filepath, (Test-Path -LiteralPath $filepath -PathType Container)

#
# Dot Source Operator

# Firstly Let's run a powershell script without dot sourcing

$c = 1

$var = "TEST"
D:\Temp\Demos.ps1
Write-Host "PARENT SCRIPT - Parent Script $Var Result: $var"


# Now let's . Source the Items in
$var = "TEST"
. D:\Temp\Demos.ps1
Write-Host "PARENT SCRIPT $Var Result: $var"

