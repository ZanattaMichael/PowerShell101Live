#
# Tokens

# Let's use write host:
Write-Host "Hello World"
# Get the last token, return "Hello World"
$$
Write-Host
# Get the last token, return "Write-Host"
$$ 

#
# Special Chars

"BASIC STRING"
"BASIC`tSTRING"

"SEND A BEEP `a"


