#
# PowerShell Automatic Variables

# OS Detection
$IsWindows
$IsCoreCLR
$IsLinux
$IsMacOS

# Arguments
$args

# Error Variable
$Error

# Directories
$Home
$PSScriptRoot

# Versioning
$PSVersionTable

# PowerShell Infomation
$PID
$PSCulture

# Parameter Information
$PSBoundParameters

