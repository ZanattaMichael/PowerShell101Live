#
# Default Get-ChildItem

Get-ChildItem -LiteralPath "C:\Windows" -File -Recurse -Hidden -Force

#
# It's Splatting Time

$params = @{
    LiteralPath = "C:\Windows"
    File = $true
    Recurse = $true
    Hidden = $true
    Force = $true
}

# Splat it in!

Get-ChildItem @params

#
# Let's make it programatic

$params = @{
    LiteralPath = Read-Host "Path"
    Recurse = $true
    Hidden = $true
    Force = $true
}

$type = Read-Host "Type. File/Directory"

# Add to the Hashtable Add("Key", "Value")
# This is adding: ("File", $true)
$params.Add($type,$true)

# This is the equivilent of not using splatting in this instance
if ($type -eq "File") {
    Get-ChildItem -File
} Else {
    Get-ChildItem -Directory
}

#
# Splat it in!
Get-ChildItem @params

#
# Let's Remove it

$params.Remove($type)


