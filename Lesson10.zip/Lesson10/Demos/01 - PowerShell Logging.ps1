#
# DEMO 01: Examples of Good Logging following the 4 W's
#


#
# Here we have a function called Update-log. This writes all the necessary information about the event.
# Note that this function appends the function (Where), The Date (When) and some other supplemental information (Log Type)

Function Update-Log {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [String]
        $Context,
        [Parameter()]
        [String]
        $FilePath="D:\TEMP\AddUser.log",
        [Parameter(Mandatory)]
        [String]
        $Function,
        [Parameter(Mandatory)]
        [ValidateSet("Warning", "Error", "Verbose", "Debug", "Information")]
        [String]
        $Type
    )

    $Entry = "[{0}] - {1} - {2} - {3}" -f $Type, $Context, $Function, (Get-Date -Format "dd:MM:yyyy hh:mm:ss")

    Add-Content -Value $Entry -LiteralPath $FilePath

}

#
# Here we have a function that is used to create a user.
# This is psudo code used for demonstration purposes.
# 
Function New-User () {
[CmdletBinding()]
    param (
        [Parameter()]
        [String]
        $UserName
    )

    #
    # Create the User


    #
    # In this logging instance I am splatting here.
    # Note that I am adding the Who and The Who.
    # Who: The UserName being Processed
    # What: We are creating the user:
    #

    #
    # Note that I have included the Types
    # Types help you filter between events that are relivent
    # In this case we used the different PowerShell output Strings
    # Error: For Errors
    # Information: Generic Log Events
    # Warning: Warnings that the user will need to be aware of
    # Verbose: More information that needs to be provided to the user if needed. I.e Creating file: C:\DEMO\123.txt
    # Debug: Debug is writing more information specific to the running of the applaction. Outputting variables values/ logic tests.
    #

    $params = @{
        Context = ("Processing: {0}" -f $UserName)
        Function = "New-User"
        Type = "Information"
    }

    # Update Log
    Update-Log @params

    Try {
        New-ADUser $UserName
    } Catch {
        Update-Log ("An Error Occured: {0}" -f $_.ErrorDetails.Message) -Type "Error" -Function "New-User"
    }

}

#
# DEMO 02: Windows Event Log:
# Let's take a look at the Windows Event Log.
# The Windows Event Log can be a very usefull place to log to:
# Note that the event log is not nativly supported within PowerShell Core.

<#
The Following Cmdlets are returned:

PSv5.1 -> C:\Users\Michael.Zanatta>Get-Command *EventLog*

CommandType     Name                                               Version    Source                                                                                                          
-----------     ----                                               -------    ------                                                                                                          
Cmdlet          Clear-EventLog                                     3.1.0.0    Microsoft.PowerShell.Management                                                                                 
Cmdlet          Get-EventLog                                       3.1.0.0    Microsoft.PowerShell.Management                                                                                 
Cmdlet          Limit-EventLog                                     3.1.0.0    Microsoft.PowerShell.Management                                                                                 
Cmdlet          New-EventLog                                       3.1.0.0    Microsoft.PowerShell.Management                                                                                 
Cmdlet          Remove-EventLog                                    3.1.0.0    Microsoft.PowerShell.Management                                                                                 
Cmdlet          Show-EventLog                                      3.1.0.0    Microsoft.PowerShell.Management                                                                                 
Cmdlet          Write-EventLog                                     3.1.0.0    Microsoft.PowerShell.Management                                                                                 
#>

# Let's take a look at the Event Log
Get-Help Get-EventLog
Get-EventLog
# You can specify the log name
Get-EventLog -LogName Application

#
# Let's Write to the Event Log

$params = @{
    LogName = 'Application'
    EntryType = 'Information'
    Category = 1
    EventId = 1
    Message = "Hello World"
    Source = "MyApp"
}

Write-EventLog @params

# So notice that the source is not avaliable
# We have to register our source and associate that source to a LogName
# We need to fix that!

# Let's use New-EventLog
New-EventLog -Source MyApp -LogName Application

# Let's Try again!
Write-EventLog @params

# Let's take a look!

Get-EventLog -LogName Application | Select-Object -First 10

# For Good Measure Let's take a look at the event log!

