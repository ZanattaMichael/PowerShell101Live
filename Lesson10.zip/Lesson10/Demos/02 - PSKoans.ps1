#
# DEMO 01: Installing PSKoans
#

Install-Module -Name PSKoans 

#
# DEMO 02: Running PSKoans
#

