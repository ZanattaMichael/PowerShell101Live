#
# Initial Demo: Demonstaion of VS Code

# Explore the Various Aspects of Code
# F8 - Run Selection
Read-Host "Enter Somthing into me:"

#
# Explore Debugging Commands
#

#
# Breakpoints (Initial)

Write-Host "Breakpoint Me"

#
# Step Into
#$var = $(
#    Write-Host "ERE"
#     Get-ChildItem -LiteralPath "C:\Windows" -File -Recurse
#)

$temp = $var | Select-Object -First 10 | Where-Object {$_.Extension -eq ".exe"}

#
# Step Over

$temp = $var | Select-Object -First 10 | Where-Object {$_.Extension -eq ".exe"}

Write-Host "Something Else Here"

#
# Step Out Of Loop

$temp = $var | Select-Object -First 10 | Where-Object {$_.Extension -eq ".exe"}

#
# VSCode Features
#

#
# Watches / Variables

$counter = 0

Do {
    Write-Host $counter
    $counter++
} Until ($Counter -eq 10)

#
# Conditional Beakpoints

#
# Expression 

# Hit Count
0 .. 10 | ForEach-Object {
    Write-Host $_
}

# Expression

# Executes PowerShell Condition
$var = "Hello World"

Write-host $Var

Write-Host "Debugging Here"
$count = 1
Write-host "Doing Other Items"

