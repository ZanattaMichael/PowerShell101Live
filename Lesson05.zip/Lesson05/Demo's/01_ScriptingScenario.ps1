<#

Develop an Script to:
1. Connect to Google.com
2. Enumerate all the links
3. Browse to the links
4. Store and output all enumerated links

#>

$URL = "https://www.google.com"

# Create a Variable Called Request
$Request = Invoke-WebRequest -Uri $URL
# We need to append the URL to the Relitive Paths, ignoring absolute paths
$EnumeratedLinks = $Request.Links.Href | ForEach-Object {
    # Test for Relitive Path    
    if (($_ -notlike "http://*") -and ($_ -notlike "https://*")) {
        # Append the URL to the Relitive Path
        Write-Output ("{0}{1}" -f $URL, $_)
    } else {
        Write-Output $_
    }
}

# Now it's time to iterate through each of the Links and Call the Respective URL
$ChildUrls = $EnumeratedLinks | ForEach-Object { 
    (Invoke-WebRequest -Uri $_).Links.Href
}

# Combine the Links
$CombinedLinks = @()
$CombinedLinks += $EnumeratedLinks
$CombinedLinks += $ChildUrls

# We now need to create absolute url paths
$CombinedLinks = $CombinedLinks | ForEach-Object {
    
    # Test for Relitive Path
    $CustomObject = [PSCustomObject]@{
        OriginalURL = $URL
        EnumeratedUrl = $_
    }
    # If it is a relitive path, append the original URL to it.
    if (($_ -notlike "http://*") -and ($_ -notlike "https://*")) {
        # Update the Property with the URL
        $CustomObject.EnumeratedUrl = "{0}{1}" -f $URL, $_
    }

    # Return to the Pipeline
    Write-Output $CustomObject

}

# Return the Combined Links to the Caller
Write-Output $CombinedLinks
