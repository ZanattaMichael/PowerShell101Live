#
# Initial Demo: Demonstration of ISE

# Explore the Various Aspects of Code
# F8 - Run Selection
#Read-Host "Enter Somthing into me:"

# 
# Explore Debugging Commands
#

#
# Break Points

Write-host "Hello World. This is me. Life should be, fun for everyone."

$tempvariable = "This is a temp variable"

# Insert Breakpoint Here
Write-Host "I am a breakpoint"

#
# Troubleshoot the Following
#

$Files = Get-ChildItem -LiteralPath "C:\Windows"

# This If Statement Should be met. Somthing is wrong with it
# Test to see if it contains .exe files

if ($Files -in ".exe") {
    Write-Host "Yes Exe Files are Present"
}

# Correct Answer
if ($Files.Extension -contains ".exe") {
    Write-Host "Yes Exe Files are Present"
}

#
# Step Into
#$var = $(
#    Write-Host "ERE"
#     Get-ChildItem -LiteralPath "C:\Windows" -File -Recurse
#)

#$var | Where-Object {$_.Extension -eq ".exe"}

#
# Step Over

$temp = $var | Select-Object -First 10 | Where-Object {$_.Extension -eq ".exe"}

Write-Host "Something Else Here"

#
# Step Out Of Loop

$temp = $var | Select-Object -First 10 | Where-Object {$_.Extension -eq ".exe"}

Write-Host "Stepped Out"
