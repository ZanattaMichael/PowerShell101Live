#
# Let's Convert To JSON

$PSObject = [PSCustomObject]@{
    Property = "Test"
    Items = @(1,2,3,4,5,6,7,8)
    Collection = @(
        [PSCustomObject]@{
            Name = "Michael"
        },
        [PSCustomObject]@{
            Name = "Tim"
        }
    )
}

# Let's Convert (Or Seralize to JSON)

$JSON = $PSObject | ConvertTo-Json

# Let's stop for a moment and explore JSON
# Note that each object is seperated by a comma,
# Note the differences between an array and an object
# Note How the data is stored (key : item)

#
# Let's Convert (Deseralize) JSON to a PS Object

$NewObject = $JSON | ConvertFrom-Json

