﻿#
# Let's Generate A Basic REST Method
#

$params = @{
    Uri = "https://randomuser.me/api"
    Method = "Get"
}

$Result = Invoke-RestMethod @params

#
# Let's Explore Result

# Note that PS has converted the code into a PSObject
$Result.GetType()

# Let's take a peek!
$Result