
#
# Data Types
#

#
# JSON Data Type

# Get the Process
$Collection = Get-ChildItem -LiteralPath C:\Windows -File | Select FullName, Id, Extension

# Convert the Object into JSON
$jsonString = $Collection | ConvertTo-Json | Out-File "C:\temp\JsonFile.json"

#
# XML Data Types

# Convert into a XML Data Type
[XML]$xmlCollection = $Collection | ConvertTo-Xml
# Save the XML File
$xmlCollection.Save("D:\Temp\XMLFile.xml")

