#
# Let's look at the Dibert SOAP API Endpoint
#

# Let's take a look at the URL endpoint: http://www.gcomputer.net/webservices/dilbert.asmx

#
# Let's look at the long way of crafting a soap query:
#

$Endpoint = 'http://www.gcomputer.net/webservices'

$params = @{
    Uri = "{0}/dilbert.asmx" -f $Endpoint
    Body = Get-Content .\SOAP_XMLBODY.xml
    Headers = @{
        SOAPAction = "{0}/TodaysDilbert" -f $Endpoint
    }
    Method = "POST"
    ContentType = "application/soap+xml"
}

$result = Invoke-WebRequest @params
$XML = [XML]$result.Content

$XML.Envelope.Body.TodaysDilbertResponse.TodaysDilbertResult

#
# New Let's do it using Proxy Classes.
#

Get-Help New-WebServiceProxy -Full

$Client = New-WebServiceProxy -Uri 'http://www.gcomputer.net/webservices/dilbert.asmx'

$Client | Get-Member

$Client.TodaysDilbert()

#
# Remember that when Create a New-WebServiceProxy, the cmdlet is connecting to the WSDL file and creating the
# associated proxy functions to communicate with the API endpoint. Let's take a look at the WSDL file
#
