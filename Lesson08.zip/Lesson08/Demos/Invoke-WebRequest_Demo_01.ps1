# -----------------------------------------------------------------------------------------
#
# Demo O1 - Basic URL Request
#
# -----------------------------------------------------------------------------------------

# Let's browse Duckduckgo

$Result = Invoke-WebRequest -Uri "https://www.duckduckgo.com"


# Let's Explore the $Result Object

# Response Status Code
$Result.StatusCode
$Result.StatusDescription
$Result.Content
$Result.RawContent
$Result.Headers
$Result.InputFields
$Result.Links

# Let's Browse Some Links
$TheAboutPage = Invoke-WebRequest -Uri ("https://duckduckgo.com{0}" -f $Result.Links[-1].href)

# -----------------------------------------------------------------------------------------
#
# Demo 2 - Let's Download a File
#
# -----------------------------------------------------------------------------------------

$params = @{
    Uri = "https://github.com/PowerShell/PowerShell/releases/download/v7.0.0-preview.1/PowerShell-7.0.0-preview.1-win-x64.zip"
    OutFile = "D:\Temp\PowerShell-7.0.0-preview.1-win-x64.zip"
}

Invoke-WebRequest @params


# -----------------------------------------------------------------------------------------
#
# Demo 3 - Let's review our previous url links
#
# -----------------------------------------------------------------------------------------

Function Format-AbsoluteUrl {
    Param(
        $Url,
        $ParentUrl
    )

    # Test for Relitive Path    
    if (($Url -notlike "http://*") -and ($Url -notlike "https://*")) {
        # Append the Url to the Relitive Path
        Write-Output ("{0}{1}" -f $ParentUrl, $_)
    } else {
        Write-Output $_
    }

}

Function Get-UrlLinks {
    Param(
        $Url
    )
    
    # Create a Variable Called Request
    $Request = Invoke-WebRequest -Uri $Url
    # We need to append the Url to the Relitive Paths, ignoring absolute paths
    $EnumeratedLinks = $Request.Links.Href | ForEach-Object { Format-AbsoluteUrl -Url $_ -ParentUrl $Url }
    
    # Now it's time to iterate through each of the Links and Call the Respective Url
    $ChildUrls = $EnumeratedLinks | ForEach-Object { 
        (Invoke-WebRequest -Uri $_).Links.Href
    }
    
    # Combine the Links
    $CombinedLinks = @()
    $CombinedLinks += $EnumeratedLinks
    $CombinedLinks += $ChildUrls
    
    # We now need to create absolute Url paths
    $CombinedLinks = $CombinedLinks | ForEach-Object {
        
        # Test for Relitive Path
        $CustomObject = [PSCustomObject]@{
            OriginalUrl = $Url
            EnumeratedUrl = Format-AbsoluteUrl -Url $_ -ParentUrl $Url
        }
    
        # Return to the Pipeline
        Write-Output $CustomObject
    
    }
    
    # Return the Combined Links to the Caller
    Write-Output $CombinedLinks   

}

Get-UrlLinks -Url "https://www.google.com"

# -----------------------------------------------------------------------------------------
#
# Demo 4 - Web Scraping with Invoke-WebRequest
#
# -----------------------------------------------------------------------------------------

# Let's define a website
#

$UpdateCatalog = Invoke-WebRequest -Uri "https://www.catalog.update.microsoft.com/Home.aspx" -SessionVariable Session

#
# We Want to Search Specific Update Catalog's

# 1: Browse to the site and run a search
# 2: Look at the results

# Note that it points to search.apsx and uses a query string to search the content. Let's use: KB2919355
# So let's re-point to it to search.aspx

$UpdateCatalog = Invoke-WebRequest -Uri "https://www.catalog.update.microsoft.com/Search.aspx?q=KB2919355" -SessionVariable Session

#
# Here let's export all the HTML out to a file and see the content

$UpdateCatalog.RawContent | Out-File -LiteralPath "D:\Temp\Invoke-WebRequest_Result.html"



